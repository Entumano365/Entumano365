{/* Previous imports and code remain the same */}

      {/* Hero Section */}
      <section className="relative h-[600px] bg-black text-white">
        {/* Background image with subtle overlay */}
        <div className="absolute inset-0">
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: 'url(/reflection-pool.jpg)'
            }}
          ></div>
          {/* Gradient overlay for better text contrast */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/50"></div>
        </div>
        <div className="relative container mx-auto px-4 h-full flex flex-col justify-center items-center text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white drop-shadow-xl">Tu hogar lejos de casa</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl text-white drop-shadow-xl">Descubre alojamientos únicos y vive experiencias inolvidables en los mejores destinos</p>
          <a 
            href="#propiedades"
            className="bg-orange-500 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-orange-600 transition-colors flex items-center space-x-2 shadow-xl"
          >
            <Calendar className="w-5 h-5" />
            <span>Reserva ahora</span>
          </a>
        </div>
      </section>

{/* Rest of the component remains the same */}